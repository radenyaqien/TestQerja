package id.radenyaqien.testqerja.ui.akun

import androidx.lifecycle.ViewModel

class AkunViewModel : ViewModel() {
}