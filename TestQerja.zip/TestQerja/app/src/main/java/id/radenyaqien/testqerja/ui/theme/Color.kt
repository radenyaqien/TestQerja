package id.radenyaqien.pexels.ui.theme

import androidx.compose.ui.graphics.Color

val Purple200 = Color(0xFF4daf92)
val pexelsColorPrimary = Color(0xFF0E7F64)
val Purple700 = Color(0xFF00523a)
val Teal200 = Color(0xFF607053)