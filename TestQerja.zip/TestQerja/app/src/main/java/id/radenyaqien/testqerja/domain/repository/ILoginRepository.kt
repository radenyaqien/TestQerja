package id.radenyaqien.testqerja.domain.repository

interface ILoginRepository {


}