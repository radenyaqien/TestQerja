package id.radenyaqien.testqerja.ui.home

data class HomeEffect(val id: String = "")
