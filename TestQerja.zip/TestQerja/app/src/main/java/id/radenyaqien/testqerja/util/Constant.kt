package id.radenyaqien.testqerja.util

object Constant {

    const val BASE_URL = "http://dev3.dansmultipro.co.id/api/recruitment/"
    const val ITEMS_PER_PAGE = 10
}